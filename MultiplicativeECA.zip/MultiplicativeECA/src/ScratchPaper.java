import java.util.Arrays;
public class ScratchPaper {
    GaloisFields gf = new GaloisFields();
    ScratchPaper() {
//        checkNumFactorIdentities(5,1);
//        checkNumFactorIdentities(2,2);
//        checkNumFactorIdentities(2,3);
//        checkNumFactorIdentities(2,4);
//        checkNumFactorIdentities(7,1);
//        checkNumFactorIdentities(11,1);
//        checkNumFactorIdentities(13,1);
//        checkNumFactorIdentities(17,1);
    }
    Fano fano = new Fano();
    public void checkFanoNumFactorsForIdentity() {
        CayleyDickson cayleyDickson = new CayleyDickson();
        int[][][] tables = fano.fanoGenerate();
        //int[][][] tables = cayleyDickson.preCalculateTables(2);
        for (int table = 0; table < tables.length; table++) {
            for (int factors = 1; factors <= 11; factors++) {
                checkNumFactorIdentities(factors, tables[table], table);
            }
        }
    }
    public void checkNumFactorIdentities(int numFactors, int[][] table, int tableNum) {
        int size = table.length;
        int[] out = new int[size];
        for (int neighborhood = 0; neighborhood < size; neighborhood++) {
            int mainFactor = neighborhood;
            for (int factor = 1; factor < numFactors; factor++) {
                mainFactor = table[mainFactor][neighborhood];
            }
            out[neighborhood] = mainFactor;
        }
        boolean isIdentity = true;
        for (int spot = 0; spot < size; spot++) {
            if (out[spot] != spot) {
                isIdentity = false;
            }
        }
        if (isIdentity) {
            System.out.println("tableNum: " + tableNum + "numFactors: " + numFactors);
            System.out.println(Arrays.toString(out));
        }
    }
    public void numFactorsRequiredForIdentity() {
        int[] primes = new int[]{2, 3, 5, 7, 11, 13, 17};
        for (int prime = 0; prime < primes.length; prime++) {
            for (int power = 1; power < 4; power++) {
                for (int factors = 1; factors < 20; factors++) {
                    checkNumFactorIdentities(primes[prime], power, factors);
                }
            }
        }
    }
    public void checkNumFactorIdentities(int p, int m, int numFactors) {
        int[][] table = gf.generateTable(p, m, false);
        int size = table.length;
        int[] out = new int[size];
        for (int neighborhood = 0; neighborhood < size; neighborhood++) {
            int mainFactor = neighborhood;
            for (int factor = 1; factor < numFactors; factor++) {
                mainFactor = table[mainFactor][neighborhood];
            }
            out[neighborhood] = mainFactor;
        }
        boolean isIdentity = true;
        for (int spot = 0; spot < size; spot++) {
            if (out[spot] != spot) {
                isIdentity = false;
            }
        }
        if (isIdentity) {
            System.out.println("p: " + p + " m: " + m + " numFactors: " + numFactors);
            System.out.println(Arrays.toString(out));
        }
    }
    public void checkNumFactorIdentities(int p, int m) {
        int[][] table = gf.generateTable(p, m, false);
        int size = table.length;
        int[] out = new int[size];
        for (int neighborhood = 0; neighborhood < size; neighborhood++) {
            int mainFactor = neighborhood;
            for (int factor = 1; factor <= 8; factor++) {
                mainFactor = table[mainFactor][neighborhood];
            }
            out[neighborhood] = mainFactor;
        }
        System.out.println("p: " + p + " m: " + m);
        System.out.println(Arrays.toString(out));
    }
    public void plot() {
        int[][] axes = new int[6][8];
        int[][] perms = PermutationsFactoradic.permSequences(3);
        for (int axis = 0; axis < 6; axis++) {
            for (int spot = 0; spot < 8; spot++) {
                int tot = 0;
                for (int power = 0; power < 3; power++) {
                    tot += (int) Math.pow(2, power) * (spot / (int) Math.pow(2, perms[axis][power]) % 2);
                }
                axes[axis][spot] = tot;
            }
        }
        for (int axis = 0; axis <  6; axis++){
            System.out.println(Arrays.toString(axes[axis]));
        }
    }
}
