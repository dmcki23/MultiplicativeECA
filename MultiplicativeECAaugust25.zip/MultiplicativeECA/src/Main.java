import java.util.Arrays;
/**
 * Standard Java Main class
 *
 */
public class Main {
    /**
     * Main class of this project
     *
     * @param args Command line arguments
     */
    public static void main(String[] args)  {

        //SwingDashboard swingDashboard = new SwingDashboard();
        Examples examples = new Examples();
        //examples.complexWolframCode(examples.complexifyWolfram(examples.generateConwayWolfram()),0);
        examples.classFourFocus();
        examples.additiveFocus();

    }


}
